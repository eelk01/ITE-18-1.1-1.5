import { defineConfig } from 'vite';

export default defineConfig({
  root: '.', // ✅ root is current folder
});
